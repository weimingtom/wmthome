Futallaby 040103

For setup instructions and latest version, please visit:
http://www.1chan.net/futallaby/

Based on GazouBBS and Futaba